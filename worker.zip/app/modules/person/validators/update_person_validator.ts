export const updatePersonValidator = {
  //
}
