export const createPersonValidator = {
  //
}
