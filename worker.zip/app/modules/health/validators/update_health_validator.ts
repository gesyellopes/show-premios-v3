export const updateHealthValidator = {
  //
}
