export const createHealthValidator = {
  //
}
