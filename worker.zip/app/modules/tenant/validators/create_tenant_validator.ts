export const createTenantValidator = {
  //
}
