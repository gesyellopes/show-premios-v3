export const updateTenantValidator = {
  //
}
