export const updateIdentityValidator = {
  //
}
