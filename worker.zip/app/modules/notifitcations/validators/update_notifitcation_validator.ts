export const updateNotifitcationValidator = {
  //
}
