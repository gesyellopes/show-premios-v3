export const createNotifitcationValidator = {
  //
}
