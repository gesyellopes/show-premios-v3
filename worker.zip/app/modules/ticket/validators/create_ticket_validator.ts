export const createTicketValidator = {
  //
}
