export const updateTicketValidator = {
  //
}
