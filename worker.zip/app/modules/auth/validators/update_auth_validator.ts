export const updateAuthValidator = {
  //
}
