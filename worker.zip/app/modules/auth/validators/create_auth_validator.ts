export const createAuthValidator = {
  //
}
