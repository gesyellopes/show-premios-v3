export const createStorageValidator = {
  //
}
