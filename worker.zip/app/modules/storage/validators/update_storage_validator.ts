export const updateStorageValidator = {
  //
}
